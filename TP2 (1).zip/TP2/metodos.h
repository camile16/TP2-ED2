#ifndef METODOS_H
#define METODOS_H

#include "heap.h"

void gerarblocos_selecao   (int n, FILE *temp, FILE **fitas, int elementos[FF], lista blocos[FF], short modo, int*, int*);
void intercalablocos       (int n, FILE *temp, FILE **fitas, int elementos[FF], lista blocos[FF], int *, int *);
void intercalablocos_f1    (int n, FILE *temp, FILE **fitas, int elementos[FF], lista blocos[FF], int *, int *);

#endif // METODOS_H