#include "heap.h"

void trocaAluno(Aluno alunos[], int a, int b) {
  Aluno aux = alunos[a];
  alunos[a] = alunos[b];
  alunos[b] = aux;
}

void trocaNum(int v[], int a, int b) {
  int aux = v[a];
  v[a] = v[b];
  v[b] = aux;
}

void swapShort(short v[], int a, int b) {
  short aux = v[a];
  v[a] = v[b];
  v[b] = aux;
}

short ehMenor(Aluno alunos[], int from[], short ativas[], int a, int b,
              short modo) {
  if (modo == 0) {
    if (ativas[from[a] % MET1] == -1)
      return 0;
    else if (ativas[from[b] % MET1] == -1)
      return 1;
    else
      return (alunos[b].nota < alunos[a].nota);
  } else {
    if (ativas[from[a]] == -1)
      return 0;
    else if (ativas[from[b]] == -1)
      return 1;
    else
      return (alunos[b].nota < alunos[a].nota);
  }
}

short ehMenor_m(Aluno alunos[], short m[], int a, int b, short modo) {
  if (modo == 0) {
    if (m[a % MET1] != 0)
      return 0;
    else if (m[b % MET1] != 0)
      return 1;
    else
      return (alunos[b].nota < alunos[a].nota);
  } else {
    if (m[a] != 0)
      return 0;
    else if (m[b] != 0)
      return 1;
    else
      return (alunos[b].nota < alunos[a].nota);
  }
}

// modo = 0 (2F fitas)
// modo = 1 (F+1 fitas)
void heapsort(Aluno alunos[], short ativas[], int from[], int n, short modo,
              int *transf, int *comp) {
  short heap; 
  do {
    heap = 1;
    for (int i = 0; i < n / 2; i++) {
      (*comp) += 4;
      if (2 * i + 2 < n &&
          ehMenor(alunos, from, ativas, 2 * i + 2, 2 * i + 1, modo)) {
        if (ehMenor(alunos, from, ativas, 2 * i + 2, i, modo)) {
          trocaAluno(alunos, i, 2 * i + 2);
          trocaNum(from, i, 2 * i + 2);
          heap = 0;
        }
      } else {
        if (ehMenor(alunos, from, ativas, 2 * i + 1, i, modo)) {
          trocaAluno(alunos, i, 2 * i + 1);
          trocaNum(from, i, 2 * i + 1);

          heap = 0;
        }
      }
    }
  } while (!heap);
}

void heapsort_marcados(Aluno alunos[], short m[], int n, short modo, int *transf,
                       int *comp) {
  short heap; 
  do {
    heap = 1;
    for (int i = 0; i < n / 2; i++) {
      (*comp) += 4;
      if (2 * i + 2 < n && ehMenor_m(alunos, m, 2 * i + 2, 2 * i + 1, modo)) {
        if (ehMenor_m(alunos, m, 2 * i + 2, i, modo)) {
          trocaAluno(alunos, i, 2 * i + 2);
          swapShort(m, i, 2 * i + 2);
          heap = 0;
        }
      } else {
        if (ehMenor_m(alunos, m, 2 * i + 1, i, modo)) {
          trocaAluno(alunos, i, 2 * i + 1);
          swapShort(m, i, 2 * i + 1);
          heap = 0;
        }
      }
    }
  } while (!heap);
}