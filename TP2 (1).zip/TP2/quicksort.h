#ifndef QUICKSORT_H
#define QUICKSORT_H

#include "box.h"

/*Declaracao dos tipos utilizados pelo quicksort externo*/
void FAVazia(TArea *Area);
int ObterNumCelOcupadas(TArea* Area);
void InsereItem(Aluno Item, TArea *Area, int&);
void RetiraPrimeiro(TArea *Area, Aluno* Item, int&);
void RetiraUltimo(TArea* Area, Aluno *Item, int&);
void ImprimeArea(TArea* Area);

/*Procedimentos utilizados pelo Particao do quicksort externo*/
void LeSup(FILE **ArqLEs, Aluno* UltLido, int* Ls, short *OndeLer, int*);
void LeInf(FILE **ArqLi, Aluno* UltLido, int* Li, short* OndeLer, int*);
void InserirArea(TArea* Area, Aluno* UltLido, int* NRArea, int*);
void EscreveMax(FILE **ArqLEs, Aluno R, int *Es, int*);
void EscreveMin(FILE **ArqEi, Aluno R, int *Ei, int*);
void RetiraMax(TArea** Area, Aluno *R, int *NRArea);
void RetiraMin(TArea** Area, Aluno* R, int *NRArea);
void Particao(FILE** ArqLi, FILE** ArqEi, FILE** ArqLEs, TArea Area, int Esq, int Dir, int*i, int*j, int& transf, int* comp);
void QuickSortExterno(FILE** ArqLi, FILE** ArqEi, FILE** ArqLEs, int Esq, int Dir, int*, int*);

#endif