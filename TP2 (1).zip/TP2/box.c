#include "box.h"

void limparAluno(Aluno* aluno) {
    aluno->inscricao = 0;
    aluno->nota = 0.0;
    aluno->estado[0] = '\0';
    aluno->cidade[0] = '\0';
    aluno->curso[0] = '\0';
}

void txtToBin(int quantidade) {
    Aluno auxAluno;
    FILE* arqLeitura = NULL;
    FILE* arqEscrita = NULL;
    int quant = 0;
    int q = 0;

    arqLeitura = fopen("PROVAO.TXT", "r");
    if (arqLeitura == NULL) {
        exit(1);
    }

    arqEscrita = fopen("PROVAO.BIN", "wb");
    if (arqEscrita == NULL) {
        fclose(arqLeitura);
        exit(2);
    }

    fseek(arqLeitura, 0, SEEK_END);
    q = ftell(arqLeitura) / 101;  // 101 bytes por linha, ajustado para evitar erro
    fseek(arqLeitura, 0, SEEK_SET);

    Aluno* vecAluno = (Aluno*)malloc(q * sizeof(Aluno));
    if (vecAluno == NULL) {
        fclose(arqLeitura);
        fclose(arqEscrita);
        exit(3);
    }

    for (int i = 0; i < quantidade; i++) {
        fscanf(arqLeitura, "%ld %lf ", &auxAluno.inscricao, &auxAluno.nota);
        fgets(auxAluno.estado, 3, arqLeitura);
        getc(arqLeitura);
        fgets(auxAluno.cidade, 51, arqLeitura);
        getc(arqLeitura);
        fgets(auxAluno.curso, 31, arqLeitura);

        vecAluno[quant] = auxAluno;
        quant++;
        limparAluno(&auxAluno);
    }

    fwrite(vecAluno, sizeof(Aluno), (size_t)quant, arqEscrita);

    fclose(arqLeitura);
    fclose(arqEscrita);
    free(vecAluno);
}
