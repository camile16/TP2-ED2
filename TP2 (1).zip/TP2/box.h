#ifndef BOX_H
#define BOX_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <time.h>

#define FITASTOTAL 20
#define MET1 (FITASTOTAL/2)
#define MET2 (FITASTOTAL - 1)

// Estrutura para armazenar os dados de cada aluno
typedef struct {
  long inscricao;
  double nota;
  char estado[3];
  char cidade[51];
  char curso[31];
} Aluno;

typedef struct elemento* celula;

typedef struct elemento {
  int valor;
  celula anterior;
  celula proximo;
} elemento;

typedef struct lista {
  celula primeiro;
} lista;

typedef int Apontador;
typedef int Chave;

typedef struct {
    Aluno Item;
    Apontador Prox, Ant;
} Celula;

typedef struct {
  Celula Itens[MET1];
  Apontador CelulasDisp, Primeiro, Ultimo;
  int NumCelOcupadas;
} TArea;

void lista_adicionar(lista *l, int valor);

int lista_removeprimeiro(lista *l);

int lista_removerelemento(lista *l, int valor);

int lista_tamanho(lista *l);

int lista_posicao(lista *l, int indice);

void lista_imprime(lista *l);

void lista_limpar(lista *l);


#endif // BOX_H