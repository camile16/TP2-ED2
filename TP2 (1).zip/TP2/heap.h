#ifndef HEAP_H
#define HEAP_H

#include "box.h"

void heapsort (Aluno alunos[], short ativas[], int from[], int n, short modo, int*, int*);
void heapsort_marcados (Aluno alunos[], short m[], int n, short modo, int*, int*);

#endif // HEAP_H